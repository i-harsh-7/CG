#include <GL/glut.h>

int ww = 1000, wh = 1000;

void init(){
	glClearColor(0, 0, 0, 1);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(-500.0, 500.0, -500.0, 500.0);
}

void axis(){
	glColor3f(0.5, 0.5, 0.5);
	
	glPointSize(1.0f);
	
	glBegin(GL_LINES);
		glVertex2i(-500, 0);
		glVertex2i(500, 0);
		
		glVertex2i(0, -500);
		glVertex2i(0, 500);
	glEnd();
}

void plotpt(int x, int y){
	glColor3f(1.0, 0.0, 0.0);
	
	glPointSize(4.0f);
	
	glBegin(GL_POINTS);
		glVertex2i(x, y);
	glEnd();
	
	
	//scaling
	int sx = 2, sy = 2;
	
	glColor3f(1.0, 0.0, 1.0);
	
	glPointSize(2.0f);
	
	glBegin(GL_POINTS);
		glVertex2i(x*sx, y*sy);
	glEnd();
	
	//reflection
	
	glColor3f(0.0, 1.0, 0.0);
	
	glPointSize(2.0f);
	
	glBegin(GL_POINTS);
		glVertex2i(x, -y);
	glEnd();

}

void bresen(int xi, int yi, int xf, int yf){
	int dx = xf - xi, dy = yf- yi;
	
	int p = 2*dy - dx;
	int cx = xi, cy = yi;
	
	if(dx >= dy){
		plotpt(cx, cy);
		
		while(cx <= xf){
			cx++;
			
			if(p >= 0){
				cy++;
				p = p + 2*dy - dx;
			}
			else{
				p = p + 2*dy;
			}
		
			plotpt(cx, cy);
		}
	}
	else{
		plotpt(cx, cy);
		
		while(cy <= yf){
			cy++;
			
			if(p < 0){
				cx++;
				p = p + 2*dx - dy;
			}
			else{
				p = p + 2*dx;
			}
		
			plotpt(cx, cy);
		}
	}
}

void dda(float xi, float yi, float xf, float yf){
	float cx = xi, cy = yi;
	
	float m = (yf - yi)/(float)(xf - xi);
	
	if(m <= 1){
		plotpt(cx, cy);
		while(cx <= xf){
			cy += m;
			
			cx++;
			
			plotpt(cx, cy);
		}
	}
	else{
		plotpt(cx, cy);
		while(cy <= yf){
			cx += 1/m;
			
			cy++;
			
			plotpt(cx, cy);
		}
	
	}

}

void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	
	axis();
	
	
	//walls
	bresen(100, 100, 200, 100);
	bresen(100, 200, 200, 200);
	
	bresen(100, 100, 100, 200);
	bresen(200, 100, 200, 200);
	
	
	//roof
	dda(100, 200, 150, 250);
	dda(150, 250, 200, 200);
	
	//window
	dda(125, 150, 175, 150);
	dda(125, 150, 125, 175);
	dda(175, 150, 175, 175);
	dda(125, 175, 175, 175);
	
	glFlush();
}

int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(wh, ww);
	
	glutCreateWindow("Temp");
	
	init();
	
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}
