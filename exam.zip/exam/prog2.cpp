#include <GL/glut.h>
#include <bits/stdc++.h>

int ww = 800, wh = 800;

int xmin = 100, ymin = 100, xmax = 500, ymax = 500;

const int I = 0;
const int L = 1;
const int R = 2;
const int B = 4;
const int T = 8;

int computeCode(int x, int y){
	int code = I;
	
	if(x < xmin) code |= L;
	else if(x > xmax) code |= R;
	
	if(y < ymin) code |= B;
	else if(y > ymax) code |= T;
	
	return code;
}

void cohen(int x1, int y1, int x2, int y2){
	int code1 = computeCode(x1, y1);
	int code2 = computeCode(x2, y2);
	
	bool accept = false;
	
	int x, y, out;
	
	while(true){
		out = (code1 != 0) ? code1 : code2;
	
		if(!(code1 | code2)){
			accept = true;
			break;
		}
		
		else if(code1 & code2){
			break;
		}
		
		else{
		
			if(x < xmin){ 
				
				y = y1 + (y2- y1)*(xmin - x2)/(x2 - x1);
				x = xmin;
			}
			else if(x > xmax){
				
				y = y1 + (y2- y1)*(xmax - x2)/(x2 - x1);
				x = xmax;
			}
			else if(y > ymax){
				x = x1 + (x2 - x1)*(ymax - y2)/(y2- y1);
				y = ymax;
			}
			else if(y < ymin){
				x = x1 + (x2 - x1)*(ymin - y2)/(y2- y1);
				y = ymin;
			}
			
			if(out == code1){
				x1 = x;
				y1 = y;
				
				code1 = computeCode(x1, y1);
			}
			else{
				x2 = x;
				y2 = y;
				
				code2 = computeCode(x2, y2);
			}
		
		}
	}
	
	if(accept){
		glColor3f(0.0, 0.0, 1.0);
		glPointSize(2.5f);
	
		glBegin(GL_LINES);
			glVertex2i(x1, y1);
			glVertex2i(x2, y2);
		
		glEnd();
	}

}

void init(){
	glClearColor(0, 0, 0, 1);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(0.0, 800.0, 0.0, 800.0);
}

void lines(){
	glColor3f(0.0, 0.0, 1.0);
		glPointSize(2.5f);
	
		glBegin(GL_LINES);
			glVertex2i(379, 500);
			glVertex2i(500, 350);
		
		glEnd();
		
		glBegin(GL_LINES);
			glVertex2i(335, 500);
			glVertex2i(100, 128);
		
		glEnd();

}


void window(){
	glColor3f(0.5, 0.5, 0.5);
	glPointSize(1.0f);
	
	glBegin(GL_LINE_LOOP);
		glVertex2i(100, 100);
		glVertex2i(100, 500);
		glVertex2i(500, 500);
		glVertex2i(500, 100);
		
	glEnd();
}

void line(int xi, int yi, int xf, int yf){
	glColor3f(1.0, 0.0, 0.0);
	glPointSize(2.0f);
	
	glBegin(GL_LINES);
		glVertex2i(xi, yi);
		glVertex2i(xf, yf);
		
	glEnd();
}

void plotcircle(int x, int y){
	glColor3f(0.0, 1.0, 0.0);
	glPointSize(2.0f);
	
	glBegin(GL_POINTS);
		glVertex2i(x, y);	glVertex2i(y, x);
		glVertex2i(x, -y);	glVertex2i(-y, x);
		glVertex2i(-x, -y);	glVertex2i(-y, -x);
		glVertex2i(-x, y);	glVertex2i(y, -x);
	glEnd();
}

void plotell(int x, int y){
	glColor3f(0.0, 1.0, 0.0);
	glPointSize(2.0f);
	
	glBegin(GL_POINTS);
		glVertex2i(x, y);	
		glVertex2i(x, -y);
		glVertex2i(-x, -y);	
		glVertex2i(-x, y);	
	glEnd();
}

void circle(int xc, int yc, int rad){
	int p = 1 - rad;

	int x = 0, y = rad;
	
	plotcircle(x+xc, y+yc);
	while(x <= y){
		x++;
	
		if(p>=0){
			p = p + 2*y - x + 1;
		}
		else{
			y--;
			p = p + 2*y + 1;
		}
		plotcircle(x+xc, y+yc);
	}
}


void ellipse(float rx, float ry, float xc, float yc){
	float x = 0, y = ry;
	
	float rx2 = rx*rx, ry2 = ry*ry;
	
	
	//region 1
	float p1 = ry2 -rx2*ry + (0.25 * rx2);
	
	plotell(x + xc, y + yc);
	while(ry2*x <= rx2*y){
		x++;
		if(p1<0){
			p1 = p1 + ry2 + 2*ry2*x;
		}
		else{
			y--;
			p1 = p1 + ry2 + 2*ry2*x - 2*rx2*y;
		}
	
		plotell(x + xc, y + yc);
	}
	
	//region 2
	float nx = x, ny = y;
	
	float p2 = ry2*(nx + 0.5)*(nx+0.5) -rx2*ry2 + rx2*(ny-1)*(ny-1);
	while(yc >=0){
		ny--;
		
		if(p2 >0){
			p2 = p2 + rx2 - 2*rx2*ny;
		}
		else{
			nx++;
			p2 = p2 + rx2 - 2*rx2*ny + 2*ry2*nx;
		}
		
		plotell(nx + xc, ny + yc);
	}

}

void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	
	window();
	
	
	circle(300, 300, 150);
	circle(225, 375, 25);
	circle(325, 375, 25);
	
	//ellipse(150, 50, 300, 200);
	
	line(50, 50, 400, 600);
	lines();
	line(125, 125, 400, 125);
	line(300, 600, 700, 100);

	glFlush();
}

int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(500, 500);
	
	glutCreateWindow("Temp");
	
	init();
	
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}
