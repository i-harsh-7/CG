#include<GL/glut.h>
#include<vector>
#include<iostream>
#include<cmath>
using namespace std;

int windowWidth = 500;
int windowHeight = 500;

int xc=0;
int yc = 0;

void plotSym(int xi, int yi){
	glVertex2i(round(xi), round(yi));
	glVertex2i(round(-xi), round(yi));
	glVertex2i(round(-xi), round(-yi));
	glVertex2i(round(xi), round(-yi));
}

void renderR2(float x, float y, int rx, int ry){
	float xc = x;
	float yc = y;
	
	float p = (ry*ry)*(xc+0.5)*(xc+0.5) + (rx*rx)*(yc-1)*(yc-1) - rx*rx*ry*ry;
	
	glBegin(GL_POINTS);
	
	while(yc>=0){
		cout <<"( " << xc << ", " << yc << " )" <<endl;
			
		plotSym(xc, yc);
		
		yc -= 1;	
		
		if(p<=0){
			xc += 1;
			p = p + 2*ry*ry*xc + rx*rx - 2*rx*rx*yc;
			
		}
		else{
			p = p - 2*rx*rx*yc + rx*rx;
		}

		
	}
	
	//plotSym(xc, yc);
	
	glEnd();
}

void renderR1(float rx, float ry){
	float xc = 0;
	float yc = ry;
	
	float p = (ry*ry) + ((rx*rx)/(float)4) - rx*rx*ry;
	
	
	cout<<"Points : "<<endl;
	glBegin(GL_POINTS);
	
	while((ry * ry * xc) <= (rx * rx * yc)){
		cout <<"( " << xc << ", " << yc << " )" <<endl;
			
		plotSym(xc, yc);	
		
		if(p<0){
			p = p + 2*ry*ry*(xc+1) + ry*ry;
		}
		else{
			p = p + 2*ry*ry*(xc+1) + ry*ry - 2*rx*rx*(yc-1);
			yc -= 1;
		}

		xc += 1;
	}
	
	plotSym(xc, yc);
	
	renderR2(xc, yc, rx, ry);
		
	glEnd();
}

void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glPointSize(4.0f);
	
	cout <<"Enter the rx and ry values : ";
	int rx , ry;
	
	cin>>rx >>ry;
	
	renderR1(rx, ry);
	
	glFlush();
}

void init(){
	glClearColor(0, 0, 0, 1);
	glColor3f(1, 1, 1);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-50, 50, -50, 50);
}


int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(windowWidth, windowHeight);
	
	glutCreateWindow("Ellipse drawing algorithm");
	
	init();
	
	glutDisplayFunc(display);
	
	glutMainLoop();
	
	return 0;
}









