#include <GL/glut.h>
#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

void init() {
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-80.0, 80.0, -80.0, 80.0);
}

void renderLine(int x1, int y1, int x2, int y2) {
	int deltaX = x2 - x1;
	int deltaY = y2 - y1;
	int curX = x1, curY = y1;
	int p = 2 * deltaY - deltaX;
	
	glBegin(GL_POINTS);
	
	cout << "Points Rendered: " << endl;
	
	if (deltaY < deltaX) {
		while (curX != x2 || curY != y2) {
			glVertex2i(curX, curY);
			cout << "(" << curX << ", " << curY << ")" << endl;
			if (p > 0) {
				curY++;
				p = p + 2*deltaY - 2*deltaX;
			} else {
				p = p + 2*deltaY;
			}
			curX++;
		}
		glVertex2i(round(curX), round(curY));
		cout << "(" << curX << ", " << curY << ")" << endl;
	} else {
		while (curX != x2 || curY != y2) {
			glVertex2i(curX, curY);
			cout << "(" << curX << ", " << curY << ")" << endl;
			if (p < 0) {
				curX++;
				p = p + 2*deltaX - 2*deltaY;
			} else {
				p = p + 2*deltaX;
			}
			curY++;
		}
		glVertex2i(curX, curY);
		cout << "(" << curX << ", " << curY << ")" << endl;
	}
	
	glEnd();
}	

void display() {
	
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(0.0, 0.0, 0.0);
	glPointSize(5.0);
	
	int delta = 0;
	vector<vector<int>> hLines = {
		{-70, -10, -70, 10},
		{-70, 0, -50, 0},
		{-50, -10, -50, 10}
	};
	vector<vector<int>> eLines = {
		{-70, -10, -70, 10},
		{-70, -10, -50, -10},
		{-70, 0, -50, 0},
		{-70, 10, -50, 10}
	};
	vector<vector<int>> lLines = {
		{-70, -10, -70, 10},
		{-70, -10, -50, -10}
	};
	vector<vector<int>> oLines = {
		{-70, -10, -70, 10},
		{-70, 10, -50, 10},
		{-50, -10, -50, 10},
		{-70, -10, -50, -10}
	};
	
	for (auto line: hLines) {
		renderLine(line[0]+delta, line[1]+delta, line[2]+delta, line[3]+delta);
	}
	delta += 30;
	for (auto line: eLines) {
		renderLine(line[0]+delta, line[1], line[2]+delta, line[3]);
	}
	delta += 30;
	for (auto line: lLines) {
		renderLine(line[0]+delta, line[1], line[2]+delta, line[3]);
	}
	delta += 30;
	for (auto line: lLines) {
		renderLine(line[0]+delta, line[1], line[2]+delta, line[3]);
	}
	delta += 30;
	for (auto line: oLines) {
		renderLine(line[0]+delta, line[1], line[2]+delta, line[3]);
	}
    
	glFlush();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(500, 500);
	glutCreateWindow("Draw Point Example");
	init();
	glutDisplayFunc(display);
	glutMainLoop();
	return 0;
}
