#include<GL/glut.h>
#include<vector>
#include<iostream>
#include<cmath>
using namespace std;

int windowWidth = 500;
int windowHeight = 500;

int xi, yi, xf, yf;

void renderLine(int xi, int yi, int xf, int yf){
	double deltaX = xf - xi;
	double deltaY = yf - yi;
	
	double slope = deltaY/deltaX;
	double curX = xi, curY = yi;
	
	cout<<"Points : "<<endl;
	glBegin(GL_POINTS);
	
	if(slope <= 1){
		while(abs(curX - xf) > 0.1){
			cout <<"( " << round(curX) << ", " << round(curY) << " )" <<endl;
			glVertex2i(round(curX), round(curY));
			curX += 1;
			curY+= slope;
		}
		cout <<"( " << round(curX) << ", " << round(curY) << " )" <<endl;
		glVertex2i(round(curX), round(curY));
	}
	else{
		while(abs(curY - yf) > 0.1){
			cout <<"( " << round(curX) << ", " << round(curY) << " )" <<endl;
			glVertex2i(round(curX), round(curY));
			curX += 1;
			curY += slope;
		}
		cout <<"( " << round(curX) << ", " << round(curY) << " )" <<endl;
		glVertex2i(round(curX), round(curY));
	}
	
	glEnd();

}

void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glPointSize(2.5f);
	
	renderLine(xi, yi, xf, yf);
	
	glFlush();
}

void init(){
	glClearColor(0, 0, 0, 1);
	glColor3f(1, 1, 1);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-50, 50, -50, 50);
}


int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(windowWidth, windowHeight);
	
	glutCreateWindow("Line Drawing by using DDA Algorithm");
	
	init();

	cout << "Enter the initial and final values : "<<endl;
	
	cin>>xi>>yi;
	cin>>xf>>yf;
	
	glutDisplayFunc(display);
	
	glutMainLoop();
	
	return 0;
}









