#include<GL/glut.h>
#include<vector>
#include<iostream>
#include<cmath>
using namespace std;

int windowWidth = 600;
int windowHeight = 600;

int xi, yi, xf, yf;

void dashedDotted(int xi, int yi, int xf, int yf) {
    	int dx = abs(xf - xi);
    	int dy = abs(yf - yi);

    	int sx = (xf > xi) ? 1 : -1;
    	int sy = (yf > yi) ? 1 : -1;

    	int x = xi;
    	int y = yi;

    	glBegin(GL_POINTS);
    	glVertex2i(x, y);
    	cout <<"( " << x << ", " << y << " )" <<endl;
    	int cnt = 0;

    	if (dx >= dy) {  
    	    	int p = 2*dy - dx;
    	    	while (x != xf) {
    	        	x += sx;
    	        	if (p >= 0) {
    	            		y += sy;
        	    		p -= 2*dx;
      	 		}
           		p += 2*dy;
           		
           		int rem = cnt%10;
           		
            		if((rem <= 3) || (rem >5 && rem <= 7))	glVertex2i(x, y);
            		cout <<"( " << x << ", " << y << " )" <<endl;
            		
            		cnt++;
        	}
    	}
    	else {        
        	int p = 2*dx - dy;
        	while (y != yf) {
        	    	y += sy;
        	    	if (p >= 0) {
        	        	x += sx;
        	        	p -= 2*dy;
        	    	}
        	    	p += 2*dx;
        	    	
        	    	int rem = cnt%10;
        	    	
        	    	if((rem <= 3) || (rem >5 && rem <= 7))	glVertex2i(x, y);
        	    	cout <<"( " << x << ", " << y << " )" <<endl;
        	    	
        	    	cnt++;
        	}
    	}	

    	glEnd();
}

void dotted(int xi, int yi, int xf, int yf) {
    	int dx = abs(xf - xi);
    	int dy = abs(yf - yi);

    	int sx = (xf > xi) ? 1 : -1;
    	int sy = (yf > yi) ? 1 : -1;

    	int x = xi;
    	int y = yi;

    	glBegin(GL_POINTS);
    	glVertex2i(x, y);
    	cout <<"( " << x << ", " << y << " )" <<endl;
    	int cnt = 0;
    	bool flag = true;
    	
    	if (dx >= dy) {  
    	    	int p = 2*dy - dx;
    	    	while (x != xf) {
    	        	x += sx;
    	        	if (p >= 0) {
    	            		y += sy;
        	    		p -= 2*dx;
      	 		}
           		p += 2*dy;
           		
            		if(flag)	glVertex2i(x, y);
            		cout <<"( " << x << ", " << y << " )" <<endl;
            		
            		cnt++;
            		if(cnt%2 == 0){
        	    		flag = (flag == true) ? false : true;
        	    	}
        	    	
        	    	
        	}
    	}
    	else {        
        	int p = 2*dx - dy;
        	while (y != yf) {
        	    	y += sy;
        	    	if (p >= 0) {
        	        	x += sx;
        	        	p -= 2*dy;
        	    	}
        	    	p += 2*dx;
        	    	
        	    	int rem = cnt%10;
        	    	
        	    	if(flag)	glVertex2i(x, y);
        	    	cout <<"( " << x << ", " << y << " )" <<endl;
        	    	
        	    	cnt++;
        	    	if(cnt%2 == 0){
        	    		flag = (flag == true) ? false : true;
        	    	}
        	    	
        	    	
        	    	
        	}
    	}	

    	glEnd();
}


void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glPointSize(3.0f);
	
	cout<<"Enter the choice : "<<endl;
	cout<< "1. Dotted \n2. Dashed - dotted"<< endl;
	int choice;
	cin >> choice;
	
	if(choice == 1) dotted(xi, yi, xf, yf);
	else if(choice == 2) dashedDotted(xi, yi, xf, yf);

	glFlush();
}

void init(){
	glClearColor(0, 0, 0, 1);
	glColor3f(1, 1, 1);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-100, 100, -100, 100);
}


int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(windowWidth, windowHeight);
	
	glutCreateWindow("Line Drawing (dotted or dashed - dotted)");
	
	init();

	cout << "Enter the initial and final values : "<<endl;
	
	cin>>xi>>yi;
	cin>>xf>>yf;
	
	glutDisplayFunc(display);
	
	glutMainLoop();
	
	return 0;
}









