#include<GL/glut.h>
#include<vector>
#include<iostream>
#include<cmath>
using namespace std;

int windowWidth = 500;
int windowHeight = 500;

int xi, yi, xf, yf;

void renderLine(int xi, int yi, int xf, int yf) {
    	int dx = abs(xf - xi);
    	int dy = abs(yf - yi);

    	int sx = (xf > xi) ? 1 : -1;
    	int sy = (yf > yi) ? 1 : -1;

    	int x = xi;
    	int y = yi;

    	glBegin(GL_POINTS);
    	glVertex2i(x, y);
    	cout <<"( " << x << ", " << y << " )" <<endl;

    	if (dx >= dy) {  
    	    	int p = 2*dy - dx;
    	    	while (x != xf) {
    	        	x += sx;
    	        	if (p >= 0) {
    	            		y += sy;
        	    		p -= 2*dx;
      	 		}
           		p += 2*dy;
            		glVertex2i(x, y);
            		cout <<"( " << x << ", " << y << " )" <<endl;
        	}
    	}
    	else {        
        	int p = 2*dx - dy;
        	while (y != yf) {
        	    	y += sy;
        	    	if (p >= 0) {
        	        	x += sx;
        	        	p -= 2*dy;
        	    	}
        	    	p += 2*dx;
        	    	glVertex2i(x, y);
        	    	cout <<"( " << x << ", " << y << " )" <<endl;
        	}
    	}	

    	glEnd();
}


void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glPointSize(5.0f);
	
	renderLine(xi, yi, xf, yf);
	
	glFlush();
}

void init(){
	glClearColor(0, 0, 0, 1);
	glColor3f(1, 1, 1);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-50, 50, -50, 50);
}


int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(windowWidth, windowHeight);
	
	glutCreateWindow("Line Drawing by using Bresenham's Algorithm");
	
	init();

	cout << "Enter the initial and final values : "<<endl;
	
	cin>>xi>>yi;
	cin>>xf>>yf;
	
	glutDisplayFunc(display);
	
	glutMainLoop();
	
	return 0;
}









