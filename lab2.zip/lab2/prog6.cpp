#include<GL/glut.h>
#include<vector>
#include<iostream>
using namespace std;


struct Point{
	int x, y;
};

vector<Point> points;


int windowWidth = 500;
int windowHeight = 500;

void mouse(int button, int state, int x, int y){
	if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN){
		Point p;
		p.x = x;
		p.y = windowHeight - y;
		
		points.push_back(p);
		
		cout<<x << ", " << y << endl;
		
		glutPostRedisplay();
	}
}

void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	
	glPointSize(4.0f);
	glBegin(GL_POINTS);
		for(auto &p : points){
			glVertex2i(p.x, p.y);
		}
	glEnd();
	
	if(points.size() >= 2){
		glBegin(GL_LINE_STRIP);
			for(auto &p : points){
				glVertex2i(p.x, p.y);
			}
		glEnd();
	}
	
	glFlush();
}

void init(){
	glClearColor(0, 0, 0, 1);
	glColor3f(1, 1, 1);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, windowWidth, 0, windowHeight);
}


int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(windowWidth, windowHeight);
	
	glutCreateWindow("Line Drawing by Mouse Clicks");
	
	init();
	
	glutDisplayFunc(display);
	glutMouseFunc(mouse);
	
	glutMainLoop();
	
	return 0;
}









