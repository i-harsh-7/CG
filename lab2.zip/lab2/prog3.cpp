#include <GL/glut.h>

int points[7][2] = {
    {50, 150},
    {75, 50},
    {100, 190},
    {125, 25},
    {150, 175},
    {175, 40},
    {200, 200}
};

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    glColor3f(1.0, 0.0, 0.0);   // Red color
    glPointSize(2.0);

    glBegin(GL_LINE_STRIP);    // Connect points with lines
    for (int i = 0; i < 7; i++) {
        glVertex2iv(points[i]);  // uses int[2]
    }

    glEnd();
    glFlush();
}

void init() {
    glClearColor(1, 1, 1, 1);
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0, 250, 0, 250);  // coordinate system
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);

    glutCreateWindow("Line Drawing using Points Array");
    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}
