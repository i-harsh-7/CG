#include <GL/glut.h>
#include <cmath>
#include <iostream>

int sides;   // number of sides

void display()
{
    glClear(GL_COLOR_BUFFER_BIT);

    float radius = 0.5f;
    float angle;

    glBegin(GL_LINE_LOOP);   // use GL_POLYGON to fill
    for (int i = 0; i < sides; i++)
    {
        angle = 2.0f * M_PI * i / sides;
        float x = radius * cos(angle);
        float y = radius * sin(angle);
        glVertex2f(x, y);
    }
    glEnd();

    glFlush();
}

void init()
{
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glColor3f(1.0, 1.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
}

int main(int argc, char** argv)
{
    std::cout << "Enter number of sides: ";
    std::cin >> sides;

    if (sides < 3)
    {
        std::cout << "Polygon must have at least 3 sides.\n";
        return 0;
    }

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Regular Polygon - GLUT");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}

