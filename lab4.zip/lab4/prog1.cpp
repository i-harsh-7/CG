#include<GL/glut.h>
#include<vector>
#include<iostream>
#include<cmath>
using namespace std;

int windowWidth = 500;
int windowHeight = 500;

int xc=0;
int yc = 0;

void renderCircle(int xi, int yi, int r){
	int xcurr = xi + 0;
	int ycurr = yi + r;
	
	int p = 1 - r;
	
	cout<<"Points : "<<endl;
	glBegin(GL_POINTS);
	
	while(xcurr <= ycurr){
		if(p <= 0){
			cout <<"( " << xcurr << ", " << ycurr << " )" <<endl;
			//cout <<"( " << xcurr << ", " << ycurr << " )" <<endl;
			//cout <<"( " << xcurr << ", " << ycurr << " )" <<endl;
			//cout <<"( " << xcurr << ", " << ycurr << " )" <<endl;
			
			glVertex2i(xcurr, ycurr);
			glVertex2i(ycurr, xcurr);
			
			glVertex2i(-xcurr, ycurr);
			glVertex2i(-ycurr, xcurr);
			
			glVertex2i(-xcurr, -ycurr);
			glVertex2i(-ycurr, -xcurr);
			
			glVertex2i(xcurr, -ycurr);
			glVertex2i(ycurr, -xcurr);
			
			xcurr++;
			
			p = p + 1 + 2*(xcurr);	
		}
		else{
			cout <<"( " << xcurr << ", " << ycurr << " )" <<endl;
			//cout <<"( " << xcurr << ", " << ycurr << " )" <<endl;
			//cout <<"( " << xcurr << ", " << ycurr << " )" <<endl;
			//cout <<"( " << xcurr << ", " << ycurr << " )" <<endl;
			
			glVertex2i(xcurr, ycurr);
			glVertex2i(ycurr, xcurr);
			
			glVertex2i(-xcurr, ycurr);
			glVertex2i(-ycurr, xcurr);
			
			glVertex2i(-xcurr, -ycurr);
			glVertex2i(-ycurr, -xcurr);
			
			glVertex2i(xcurr, -ycurr);
			glVertex2i(ycurr, -xcurr);
			
			xcurr++;
			ycurr--;
			
			p = p + 1 + 2*(xcurr)- 2*ycurr;	
		}	
	}
	
	glEnd();
}

void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glPointSize(2.5f);
	
	//cout <<"Enter the radius : ";
	int r = 10;
	
	renderCircle(xc, yc, r);
	
	glFlush();
}

void init(){
	glClearColor(0, 0, 0, 1);
	glColor3f(1, 1, 1);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-50, 50, -50, 50);
}


int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(windowWidth, windowHeight);
	
	glutCreateWindow("Circle Drawing by using mid - point Algorithm origin (0, 0)");
	
	init();

	//cout << "Enter the initial and final values : "<<endl;
	
	//cin>>xi>>yi;
	//cin>>xf>>yf;
	
	glutDisplayFunc(display);
	
	
	
	glutMainLoop();
	
	return 0;
}









