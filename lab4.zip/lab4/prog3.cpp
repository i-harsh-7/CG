#include<GL/glut.h>
#include<vector>
#include<iostream>
#include<cmath>
using namespace std;

int windowWidth = 500;
int windowHeight = 500;

int xc=0;
int yc = 0;

void renderCircle(int xi, int yi, int x1, int y1, int r){
	int xcurr = 0;
	int ycurr = r;
	
	int p = 1 - r;
	
	cout<<"Points : "<<endl;
	glBegin(GL_POINTS);
	
	while(xcurr <= ycurr){
		if(p <= 0){
			cout <<"( " << xcurr + x1 << ", " << ycurr + y1<< " )" <<endl;
			
			glVertex2i(xcurr + x1, ycurr + y1);
			glVertex2i(ycurr + y1, xcurr + x1);
			
			glVertex2i(-xcurr + x1, ycurr + y1);
			glVertex2i(-ycurr + y1, xcurr + x1);
			
			glVertex2i(-xcurr + x1, -ycurr + y1);
			glVertex2i(-ycurr + y1, -xcurr + x1);
			
			glVertex2i(xcurr + x1, -ycurr + y1);
			glVertex2i(ycurr + x1, -xcurr + x1);
			
			xcurr++;
			
			p = p + 1 + 2*(xcurr);	
		}
		else{
			cout <<"( " << xcurr << ", " << ycurr << " )" <<endl;
			
			glVertex2i(xcurr + x1, ycurr + y1);
			glVertex2i(ycurr + y1, xcurr + x1);
			
			glVertex2i(-xcurr + x1, ycurr + y1);
			glVertex2i(-ycurr + y1, xcurr + x1);
			
			glVertex2i(-xcurr + x1, -ycurr + y1);
			glVertex2i(-ycurr + y1, -xcurr + x1);
			
			glVertex2i(xcurr + x1, -ycurr + y1);
			glVertex2i(ycurr + x1, -xcurr + x1);
			
			xcurr++;
			ycurr--;
			
			p = p + 1 + 2*(xcurr)- 2*ycurr;	
		}	
	}
	
	glEnd();
}

void display(){
	glClear(GL_COLOR_BUFFER_BIT);
	glPointSize(2.5f);

	cout<<"Enter the center coordinates : ";
	int x, y;
	cin>>x >> y;
	
	cout <<"Enter the radius of first circle: ";
	int r1;
	cin>>r1;
	
	renderCircle(xc, yc, x, y, r1);
	
	cout <<"Enter the radius of second circle: ";
	int r2;
	cin>>r2;

	renderCircle(xc, yc, x, y, r2);
	
	glFlush();
}

void init(){
	glClearColor(0, 0, 0, 1);
	glColor3f(1, 1, 1);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-50, 50, -50, 50);
}


int main(int argc, char** argv){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(windowWidth, windowHeight);
	
	glutCreateWindow("Circle Drawing by using mid - point Algorithm origin (0, 0)");
	
	init();
	
	glutDisplayFunc(display);
	
	glutMainLoop();
	
	return 0;
}









