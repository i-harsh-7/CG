#include <GL/glut.h>
#include <cmath>

float x1 = 0, y1_coord = -2;
float x2 = 4, y2_coord = 5;

void drawAxis(){
	glColor3f(0.5, 0.5, 0.5);
	glLineWidth(1.0);
	glBegin(GL_LINES);
		glVertex2f(-10, 0);
		glVertex2f(10, 0);
	glEnd();
	glBegin(GL_LINES);
		glVertex2f(0, 10);
		glVertex2f(0, -10);
	glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
	drawAxis();
    glLineWidth(3.0);

    glColor3f(1.0, 1.0, 1.0);
    glBegin(GL_LINES);
        glVertex2f(x1, y1_coord);
        glVertex2f(x2, y2_coord);
    glEnd();
	
	// reflect along x axis	
	float new_y1 = -y1_coord, new_y2 = -y2_coord; 
	float new_x1 = x1, new_x2 = x2;
	
    glColor3f(1.0, 0.0, 0.0);
    glBegin(GL_LINES);
        glVertex2f(new_x1, new_y1);
        glVertex2f(new_x2, new_y2);
    glEnd();
	
	// reflect along y axis	
	new_y1 = y1_coord, new_y2 = y2_coord; 
	new_x1 = -x1, new_x2 = -x2;
	
	glColor3f(0.0, 0.0, 1.0);
    glBegin(GL_LINES);
        glVertex2f(new_x1, new_y1);
        glVertex2f(new_x2, new_y2);
    glEnd();
	
    glFlush();
}

void init() {
    glClearColor(0.0, 0.0, 0.0, 1.0);
    gluOrtho2D(-10, 10, -10, 10);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Ladder");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}
