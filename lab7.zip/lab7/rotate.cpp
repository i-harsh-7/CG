#include <GL/glut.h>
#include <cmath>

float angle = 45.0 * 3.14159265 / 180.0;


float vx[] = {0 , 5, 3}, vy[] = {0, 0, 2};


void drawTriangle(float x[], float y[]) {
    glBegin(GL_LINE_LOOP);
    for(int i = 0; i < 3; i++)
        glVertex2f(x[i], y[i]);
    glEnd();
}

void drawAxis(){
	glColor3f(0.5, 0.5, 0.5);
	glLineWidth(1.0);
	glBegin(GL_LINES);
		glVertex2f(-10, 0);
		glVertex2f(10, 0);
	glEnd();
	glBegin(GL_LINES);
		glVertex2f(0, 10);
		glVertex2f(0, -10);
	glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    drawAxis();
    glLineWidth(3.0);
    
	glColor3f(1.0, 1.0, 1.0);
	drawTriangle(vx, vy);
	
	for(int i = 0; i < 3; i++){
		float temp = vx[i] * cos(angle) - vy[i] * sin(angle);
    	vy[i] = vx[i] * sin(angle) + vy[i] * cos(angle);
		vx[i] = temp;
	}
	
	glColor3f(1.0, 0, 0);
	drawTriangle(vx, vy);
	
    glFlush();
}

void init() {
    glClearColor(0.0, 0.0, 0.0, 1.0);
    gluOrtho2D(-10, 10, -10, 10);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Triangle");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}
