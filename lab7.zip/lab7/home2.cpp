#include <GL/glut.h>
#include <cmath>

float angle = 45.0 * 3.14159265 / 180.0;

int lim = 20;

float tx[] = {0 , 2, 1}, ty[] = {0, 0, 1};
float rx[] = {0 , 6, 6, 0}, ry[] = {0, 0, 9, 9};

void drawShape(float x[], float y[], int n, int sx, int sy) {
    glBegin(GL_LINE_LOOP);
    for(int i = 0; i < n; i++)
        glVertex2f(x[i]+sx, y[i]+sy);
    glEnd();
}

void drawAxis(){
	glColor3f(0.5, 0.5, 0.5);
	glLineWidth(1.0);
	glBegin(GL_LINES);
		glVertex2f(-lim, 0);
		glVertex2f(lim, 0);
	glEnd();
	glBegin(GL_LINES);
		glVertex2f(0, lim);
		glVertex2f(0, -lim);
	glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    drawAxis();
    glLineWidth(3.0);
    
	glColor3f(1.0, 1.0, 1.0);
	drawShape(tx, ty, 3, 7, 9);
	
	
	glColor3f(1.0, 0, 0);
	drawShape(rx, ry, 4, 5, 0);
	
    glFlush();
}

void init() {
    glClearColor(0.0, 0.0, 0.0, 1.0);
    gluOrtho2D(-lim, lim, -lim, lim);
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(600, 600);
    glutCreateWindow("Triangle");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}
